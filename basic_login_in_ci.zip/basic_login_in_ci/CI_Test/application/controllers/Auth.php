<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Auth extends CI_Controller {

	public function __construct(){
		parent::__construct();
		$this->load->model("auth_model");
	}

	public function login()
	{
		if(isset($_SESSION['user_logged'])){
			redirect("user/profile","refresh");
		}

		if(isset($_POST["login"])){
			
			$this->form_validation->set_rules('email','Email','required|valid_email');
			$this->form_validation->set_rules('pwd','Password','required|min_length[5]');

			if($this->form_validation->run()==TRUE){
				$user = "";
				$email    = $_POST["email"];
				$password = md5($_POST["pwd"]);

				$user = $this->auth_model->authenticate_user($email,$password);

				if(isset($user->email)){
					$this->session->set_flashdata("success","you are logged in..");
					$_SESSION["user_logged"] = TRUE;
					$_SESSION["user_name"] = $user->user_name;
					$_SESSION["email"] = $user->email;
					redirect("user/profile","refresh");
				}else{
					$this->session->set_flashdata("error","No such account found in the database.");
					redirect("auth/login","refresh");
				}
			}
		}
		$this->load->view("login");
	}

	public function register()
	{
		if(isset($_SESSION['user_logged'])){
			redirect("user/profile","refresh");
		}
		
		if(isset($_POST["register"])){
			$this->form_validation->set_rules('username','Username','required');
			$this->form_validation->set_rules('email','Email','required|valid_email');
			$this->form_validation->set_rules('pwd','Password','required|min_length[5]');
			$this->form_validation->set_rules('cpwd','Confrim Password','required|min_length[5]|matches[pwd]');
			if($this->form_validation->run()==TRUE){
				$data = array(
							"user_name"    => $_POST["username"],
							"email"        => $_POST["email"],
							"password"     => md5($_POST["pwd"]),
							"created_date" => date("Y-m-d"),
						);

				if($this->auth_model->insert($data)){
					$this->session->set_flashdata("success","Your account has been registered.");
					redirect("auth/register","refresh");
				}else{
					$this->session->set_flashdata("error","Your account has not been registered.");
					redirect("auth/register","refresh");
				}
				
			}
		}

		$this->load->view("register");
	}

	public function logout(){
		session_destroy();
		redirect("auth/login","refresh");
	}
}
