<?php
class Auth_model extends CI_Model {

	public function __construct(){
		parent::__construct();

	}

	public function insert($data){
		$return = $this->db->insert("users",$data);
		return $return;
	}


	public function authenticate_user($email, $password) {
        $this->db->select('*');
        $this->db->from('users');
        $this->db->where('email', $email);
		$this->db->where('password', $password);
		$this->db->limit(1);
        $Q = $this->db->get();
        if ($Q->num_rows() > 0) {
            $return = $Q->row();
        } else {
            $return = 0;
        }
        $Q->free_result();
        return $return;
    }
	
}
