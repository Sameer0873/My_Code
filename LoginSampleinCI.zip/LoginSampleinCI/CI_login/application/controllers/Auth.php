<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Auth extends CI_Controller {

	public function __construct(){
		parent::__construct();
		
	}

	public function login()
	{
		if(isset($_SESSION['user_logged'])){
			redirect("user/profile","refresh");
		}

		if(isset($_POST["login"])){
			
			$this->form_validation->set_rules('email','Email','required|valid_email');
			$this->form_validation->set_rules('pwd','Password','required|min_length[5]');
			if($this->form_validation->run()==TRUE){
				$user = "";
				$email    = $_POST["email"];
				$password = md5($_POST["pwd"]);

				$this->db->select();
				$this->db->from("users");
				$this->db->where(array("email"=>$email,"password"=>$password));
				$query = $this->db->get();
				$user = $query->row();
				if(isset($user->email)){
					$this->session->set_flashdata("success","you are logged in..");
					$_SESSION["user_logged"] = TRUE;
					$_SESSION["user_name"] = $user->user_name;
					$_SESSION["email"] = $user->email;
					redirect("user/profile","refresh");
				}else{
					$this->session->set_flashdata("error","No such account found in the database.");
					redirect("auth/login","refresh");
				}
				// $data = array(
				// 			"user_name"    => $_POST["username"],
				// 			"email"        => $_POST["email"],
				// 			"password"     => $_POST["pwd"],
				// 			"created_date" => date("Y-m-d"),
				// 		);
				// $this->db->insert("users",$data);
				// $this->session->set_flashdata("success","Your account has been registered.");
				// redirect("auth/register","refresh");
			}
		}
		$this->load->view("login");
	}

	public function register()
	{
		if(isset($_SESSION['user_logged'])){
			redirect("user/profile","refresh");
		}
		
		if(isset($_POST["register"])){
			$this->form_validation->set_rules('username','Username','required');
			$this->form_validation->set_rules('email','Email','required|valid_email');
			$this->form_validation->set_rules('pwd','Password','required|min_length[5]');
			$this->form_validation->set_rules('cpwd','Confrim Password','required|min_length[5]|matches[pwd]');
			if($this->form_validation->run()==TRUE){
				$data = array(
							"user_name"    => $_POST["username"],
							"email"        => $_POST["email"],
							"password"     => md5($_POST["pwd"]),
							"created_date" => date("Y-m-d"),
						);
				$this->db->insert("users",$data);
				$this->session->set_flashdata("success","Your account has been registered.");
				redirect("auth/register","refresh");
			}
		}
		$this->load->view("register");
	}

	public function logout(){
		session_destroy();
		redirect("auth/login","refresh");
	}
}
