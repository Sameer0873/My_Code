<?php
if(isset($_FILES["imagefile"]["type"]))
{
	$validextensions = array("jpeg", "jpg", "png");
	$temporary       = explode(".", $_FILES["imagefile"]["name"]);
	$file_extension  = end($temporary);
	
	if ((($_FILES["imagefile"]["type"] == "image/png") || ($_FILES["imagefile"]["type"] == "image/jpg") || ($_FILES["imagefile"]["type"] == "image/jpeg")) && ($_FILES["imagefile"]["size"] < 100000) && in_array($file_extension, $validextensions)) {
		if ($_FILES["imagefile"]["error"] > 0)
		{
			echo "Return Code: " . $_FILES["imagefile"]["error"] . "<br/><br/>";
		}
		else
		{
			if (file_exists("upload/" . $_FILES["imagefile"]["name"])) {
				echo $_FILES["imagefile"]["name"] . " <span id='invalid'><b>already exists.</b></span> ";
			}
			else
			{
				$sourcePath = $_FILES['imagefile']['tmp_name']; // Storing source path of the file in a variable
				$targetPath = "upload/".$_FILES['imagefile']['name']; // Target path where file is to be stored
				move_uploaded_file($sourcePath,$targetPath) ; // Moving Uploaded file
				echo "<span id='success'>Image Uploaded Successfully...!!</span><br/>";
				echo "<br/><b>File Name:</b> " . $_FILES["imagefile"]["name"] . "<br>";
				echo "<b>Type:</b> " . $_FILES["imagefile"]["type"] . "<br>";
				echo "<b>Size:</b> " . ($_FILES["imagefile"]["size"] / 1024) . " kB<br>";
				echo "<b>Temp file:</b> " . $_FILES["imagefile"]["tmp_name"] . "<br>";
			}
		}
	}
	else
	{
		echo "<span id='invalid'>***Invalid file Size or Type***<span>";
	}
}
?>