<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>File uplaod using ajax</title>
</head>
<body>
	<form id="uploadimage" action="" method="POST" enctype="multipart/form-data">
		<input type="text" name="firstname" id="firstname">
		<input type="file" name="imagefile" id="imagefile">
		<input type="submit" value="Upload" name="uplaod" class="submit" />
	</form>
	<div id="success"></div>
	<script src="http://code.jquery.com/jquery-3.3.1.js"></script>
	<script type="text/javascript">
		$(document).ready(function(e){
			$("#uploadimage").on('submit',function(e) {
				e.preventDefault();
				$.ajax({
					url: "ajax_php_file.php", // Url to which the request is send
					type: "POST",             // Type of request to be send, called as method
					data: new FormData(this), // Data sent to server, a set of key/value pairs (i.e. form fields and values)
					contentType: false,       // The content type used when sending data to the server.
					cache: false,             // To unable request pages to be cached
					processData:false,        // To send DOMDocument or non processed data file it is set to false
					success: function(data)   // A function to be called if request succeeds
					{
						$("#success").html(data);
					}
				});
			});
		});
	</script>
</body>
</html>